setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

bwts <- read.table("Data/bwts.txt", header = TRUE, sep = "\t")

colnames(bwts) <- c("LowBw", "Age", "LastWeight", "Race", "Smoking", "PrevPremature",
                    "Hypertension", "UterineIrritab", "PhysVisits", "BirthWeight")

ynf <- function(x) factor(x, levels = 0:1, labels = c("No", "Yes"))
bwts <- transform(bwts, LowBw = ynf(LowBw), Smoking = ynf(Smoking), 
                  PrevPremature = ynf(PrevPremature), 
                  Hypertension = ynf(Hypertension),
                  UterineIrritab = ynf(UterineIrritab),
                  Race = factor(Race, levels = 1:3, labels = c("White", "Black", "Other"))
          )

summary(bwts)

save(bwts, file = "Data/bwts.RData")