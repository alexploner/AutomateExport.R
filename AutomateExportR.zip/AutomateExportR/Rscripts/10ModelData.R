setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

load("Data/bwts.RData")

bwts_lr <- glm(LowBw ~ . - BirthWeight, data = bwts, family = binomial)
summary(bwts_lr)

save(bwts_lr, file = "Data/bwts_model.RData")