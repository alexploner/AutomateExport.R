setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

load("Data/bwts.RData")
load("Data/bwts_model.RData")

#' Descriptives
library(gtsummary)
desc_tab_gt <- tbl_summary(bwts, by = LowBw)
desc_tab_gt
as_flex_table(desc_tab_gt) |> flextable::save_as_docx(path = "Tables/bwts_table1.docx")

#' Regression table
regtab_gt <- tbl_regression(bwts_lr, exponentiate = TRUE)
regtab_gt
as_flex_table(regtab_gt) |> flextable::save_as_docx(path = "Tables/bwts_regtab.docx")
##as_tibble(regtab_gt) |> tinytable::tt() |> tinytable::save_tt("../Tables/bwts_regtab.docx", overwrite = TRUE)

#' Simple boxplots
library(ggplot2)
library(patchwork)
pl1 <- ggplot(bwts, aes(x = LowBw, y = Age)) + geom_boxplot()
pl2 <- ggplot(bwts, aes(x = LowBw, y = LastWeight)) + geom_boxplot()
pl <- pl1 + pl2
pl

ggsave(filename = "Plots/bwts_boxplots.png", pl,  
  width = 18, height = 10, units = "cm", dpi = 300)
