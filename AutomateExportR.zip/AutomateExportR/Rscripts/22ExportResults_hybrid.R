#' Workshop 2024-10-15: scripted workflow/export results, hybrid script
#' alexander.ploner@ki.se


#+ setup, include=FALSE
knitr::opts_chunk$set(echo = FALSE, dpi = 300, comment = NA, strip.white = TRUE,
  warning = FALSE, message = FALSE)
setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")
knitr::opts_knit$set(root.dir = getwd())
load("Data/bwts.RData")
load("Data/bwts_model.RData")


#' Table 1
#' -------

#+ table1, tab.cap="Table 1: Descriptive statistics"
library(gtsummary)
desc_tab_gt <- tbl_summary(bwts, by = LowBw, 
  type = PhysVisits ~ "continuous", 
  statistic =  list( c(all_continuous(), -PhysVisits) ~ "{mean} ({sd})",  
                     PhysVisits ~ "{median} ({min}, {max})"),
  missing_text = "(Missing)", 
  label = list(LowBw = "Low birth weight", BirthWeight = "Birth weight (g)",
  Age = "Age (yrs)", LastWeight = "Weight at last menstruation (lbs)", 
  UterineIrritab = "Uterine irritability", PrevPremature = "Previous premature labour",
  PhysVisits = "Physician visits during 1st trimester")
  ) |> add_overall()
desc_tab_gt


#' Regression table
#' ----------------

#+ regtab, tab.cap="Table 2: Regression parameters"
regtab_gt <- tbl_regression(bwts_lr, exponentiate = TRUE, 
  show_single_row = all_dichotomous(), intercept = FALSE,
  label = list(LowBw = "Low birth weight", BirthWeight = "Birth weight (g)",
  Age = "Age (yrs)", LastWeight = "Weight at last menstruation (lbs)", 
  UterineIrritab = "Uterine irritability", PrevPremature = "Previous premature labour",
  PhysVisits = "Physician visits during 1st trimester")) 
regtab_gt

#' Boxplots
#' --------

#+ figboxplt, fig.width = 18/2.54, fig.height = 12/2.54, fig.cap="Figure 1: Boxplots"
library(ggplot2)
library(patchwork)
pl1 <- ggplot(bwts, aes(x = LowBw, y = Age)) + geom_boxplot()
pl2 <- ggplot(bwts, aes(x = LowBw, y = LastWeight)) + geom_boxplot()
pl <- pl1 + pl2
pl

