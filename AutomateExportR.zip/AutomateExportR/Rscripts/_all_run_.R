## Workshop 2024-10-15: batch script v1 / classic
## alexander.ploner@ki.se

setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

source("Rscripts/00ReadData.R")
source("Rscripts/10ModelData.R")
source("Rscripts/20ExportResults.R")
