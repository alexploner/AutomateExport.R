## Workshop 2024-10-15: batch script v2 / using render() for logfiles
## alexander.ploner@ki.se

setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

library(rmarkdown)
knitr::opts_knit$set(root.dir = getwd())

render("Rscripts/00ReadData.R", output_dir = "Log")
render("Rscripts/10ModelData.R", output_dir = "Log")
render("Rscripts/20ExportResults.R", output_dir = "Log")
