## Workshop 2024-10-15: batch script v3 / using render() with mixed .R/.Rmd 
## alexander.ploner@ki.se

setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

library(rmarkdown)
knitr::opts_knit$set(root.dir = getwd())

render("Rscripts/00ReadData.R", output_dir = "Log")
render("Rscripts/10ModelData.R", output_dir = "Log")
render("Rscripts/21ExportResults.Rmd", output_dir = "Log",  
       output_format = "word_document")
