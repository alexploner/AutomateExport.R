## Workshop 2024-10-15: batch script v4 / using render() with vanilla .R, hybrid .R
## alexander.ploner@ki.se

setwd("C:/Users/aleplo/OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR")

library(rmarkdown)
knitr::opts_knit$set(root.dir = getwd())

render("Rscripts/00ReadData.R", output_dir = "Log")
render("Rscripts/10ModelData.R", output_dir = "Log")
render("Rscripts/22ExportResults_hybrid.R", output_dir = "Log",  
       output_format = "word_document")

## Compare this with sourcing the hybrid file (no log)
## source("Rscripts/22ExportResults_hybrid.R")
