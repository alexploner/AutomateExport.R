# base-script.R
#
# 
#
# Alexander.Ploner@ki.se 2024-10-01

# Set working directory, read data
##setwd("~/@OneDriveKI/DM_workshops/AutomateExportR/")
setwd("~/../OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR/")
cvd <- read.delim("CVD.txt", stringsAsFactors = TRUE)
summary(cvd)

#' Direct conversion
cvd$cvd <- factor(cvd$cvd,  levels = 0:1, labels = c("no", "yes"))
cvd$sex <- factor(cvd$sex,  levels = 0:1, labels = c("f", "m"))

#' Check the numerical codes
boxplot(alc ~ alc2, cvd)
cvd$alc2 <- factor(cvd$alc2, levels = 0:1, labels = c("low", "high"))
boxplot(alc ~ alc3, cvd)
cvd$alc3 <- factor(cvd$alc3, levels = 0:2, labels = c("low", "medium", "high"))

#' Better already
summary(cvd)

#' 3-level categorisation splits 2-level high category
tab <- table(cvd$alc3, cvd$alc2)
tab

#' We have not discussed by-group analysis yet (Module III), but we can do subset
#' Sneaky alternative: compare the cumulative percentages of alc and alc2/3 in
#' the freq-output above (not shown)
range( subset(cvd, alc2 == "low")$alc )
range( subset(cvd, alc2 == "high", select = "alc") )

range( subset(cvd, alc3 == "low", select = "alc") )
range( subset(cvd, alc3 == "medium", select = "alc") )
range( subset(cvd, alc3 == "high", select = "alc") )

#' More subsetting
library(DescTools)
MeanCI( subset(cvd, cvd == "no")$alc )
MeanCI( subset(cvd, cvd == "yes")$alc )

#' Easier for tables
tab <- table(cvd$alc3, cvd$cvd)
tab
proportions(tab, margin = 1)

#' Breaking it down for BinomCI with our current tool set is still awkward
low_cvd <- subset(cvd, alc3 == "low")$cvd
table(low_cvd)
BinomCI( table(low_cvd), n = length(low_cvd) )

#' Well, this is easy
library(epitools)
epitab( tab )

logreg0 <- glm(cvd ~ alc3, data = cvd, family = binomial)
summary(logreg0)

logreg <- glm(cvd ~ alc3 + sex, data = cvd, family = binomial)
summary(logreg)

save(cvd, file = "cvd.RData")


library(gtsummary)
tbl_summary(cvd, by = "cvd", include = -ID)
tbl_summary(cvd, by = "cvd", include = c(sex, alc3))
tbl_regression(logreg0)
tbl_regression(logreg)

library(flextable)
library(huxtable)






#' Something nicer
library(summarytools)
#' Mostly useful, except for alc
freq(cvd, report.nas = FALSE)
#' Really only useful for alc
descr(cvd)
