#' make_table.R
#' 
#' Generate tables to export
#' 
#' Alexander.Ploner@ki.se   2024-10-12

setwd("~/@OneDriveKI/DM_workshops/AutomateExportR/")
setwd("~/../OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR/")

load("birthweights.RData")

#' Arsenal - default
library(arsenal)
tab_arse <- tableby(LowBw ~ ., data = bwts)
summary(tab_arse)
write2word(tab_arse, "tab_arse.docx", title = "Birthweights")
#' Convert to data frame / tiny table
tab_arse_df <- summary(tab_arse) |> as.data.frame()
tab_arse_df
tinytable::tt(tab_arse_df)
#' Arsenal - something more useful 
tab_arse2 <- tableby(LowBw ~ BirthWeight + Age + LastWeight + Smoking + Race + 
                             PrevPremature + Hypertension + UterineIrritab + 
                             notest(PhysVisits, "medianrange", "Nmiss"),
                     data = bwts, test = FALSE, 
                     numeric.simplify = TRUE, cat.simplify = "label",
                     cat.stats = c("countpct", "Nmiss"),
                     numeric.stats = c("meansd", "Nmiss"), digits = 1)
labels(tab_arse2) <- c(LowBw = "Low birth weight", Age = "Age", 
   LastWeight = "Weight at last menstruation", Race = "Race", 
   Smoking = "Smoking", PrevPremature = "Previous premature labour", 
   Hypertension = "Hypertension", UterineIrritab = "Uterine irritability", 
   PhysVisits = "Physician visits 1st trimester", BirthWeight = "Birth weight")
summary(tab_arse2)
write2word(tab_arse2, "tab_arse2.docx", title = "Birthweights")
#' Fake IR for arsenal?
#' write2 is quite versatile


#' table1
#' very HTML centric
#' requires functions for chaning rendering 
#' less flexible with variable labels, compression of rows etc. 
library(table1)
tab_table1 <- table1(~.|LowBw, data = bwts)
tab_table1
tab_table1_df <- as.data.frame(tab_table1)
tab_table1_df
tab_table1_df |> tinytable::tt()

#' gtsummary
library(gtsummary)
tab_gtsum <- tbl_summary(bwts, by = LowBw)
tab_gtsum
print(tab_gtsum, "kable")
as_gt(tab_gtsum) |> gt::gtsave("tab_gtsum.docx")
#' Pretty good out of the box, can we do better
select(bwts, BirthWeight, Age, LastWeight, Smoking, Race, PrevPremature,
             Hypertension, UterineIrritab, PhysVisits, LowBw) |>
tbl_summary(by = LowBw, 
            label = list(LowBw = "Low birth weight", Age = "Age (years)", 
                         LastWeight = "Weight at last menstruation (lbs)", Race = "Race", 
                         Smoking = "Smoking", PrevPremature = "Previous premature labour", 
                         Hypertension = "Hypertension", UterineIrritab = "Uterine irritability", 
                         PhysVisits = "Physician visits 1st trimester", BirthWeight = "Birth weight (g)"),
            type = list(PhysVisits ~ "continuous"),
            statistic = list(all_continuous() ~ "{mean} ({sd})",
                             PhysVisits ~ "{median} ({min}, {max})")
            ) |> add_overall() -> tab_gtsum2 
tab_gtsum2
as_gt(tab_gtsum2) |> gt::gtsave("tab_gtsum2.docx")



logreg <- glm(LowBw ~ . - BirthWeight, data = bwts, family = binomial)

library(broom)
tidy(logreg, conf.int = TRUE, exponentiate = TRUE) -> logreg_tab
logreg_tab
library(tinytable)
tt(logreg_tab[, -c(3:4)]) |> 
  format_tt(digits = 2, num_zero = TRUE) |>
  format_tt(j = 3, num_fmt = "scientific", digits = 1) |>
  print(output = "markdown")

library(gtsummary)
tbl_regression(logreg, exponentiate = TRUE, show_single_row = all_dichotomous()) |>
  remove_row_type(type = "reference") |>
##  as_gt() |> gt::gtsave("logreg_gtsum2.docx") ## does not work (pandoc error 22; cannot save doc)
  as_flex_table() |> flextable::save_as_docx(path = "logreg_gtsum2.docx")

#' At least as.data.frame seems to work


tbl_regression(logreg, exponentiate = TRUE) |>
  combine_terms(formula_update = . ~ . - Race)

#' Very limited, but does cover glm, ordinal regression, coxph
#' fitting included???
library(arsenal)
logreg_arse <- modelsum(LowBw ~ . - BirthWeight, data = bwts, family = binomial)
logreg_arse |> summary()



