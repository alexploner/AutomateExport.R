source("base_script.R")

rmarkdown::render("base_script.R", output_dir = "Log")

rmarkdown::render("saveplot.Rmd", output_dir = "Log")