setwd("~/@OneDriveKI/DM_workshops/AutomateExportR/")
##setwd("~/../OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR/")
cvd <- read.delim("CVD.txt", stringsAsFactors = TRUE)

boxplot(alc ~ sex, data = cvd)

#' Formats in manual:
#' 
#' PNG, JPEG, TIFF, BMP, Metafile, SVG, Eps
#' PDF separate

#' bitmap formats have 72ppi as default -> prints crap? 

devfun <- c(png, jpeg, tiff, bmp)
ext    <- c("png", "jpeg", "tiff", "bmp")
for (i in seq_along(devfun))
{
  devfun[[i]](paste("fig/bxplot_dev_default", ext[i], sep="."))
  boxplot(alc ~ sex, data = cvd)
  dev.off()
}

#' Packages extrafont showtext

# Really for PDF/postscript (-> LaTeX), also happens to work for bitmap on Windows 
# systems
#library(extrafont)
#font_import() ## only once? slow, works on windows; re-run for updated R? 
#loadfonts(device="win") ## for windows device, bitmap
#png("test.png", family = "Vladimir Script", pointsize = 20)
#boxplot(alc ~ sex, data = cvd)
#dev.off() 


#' Slightly weird: pointsize works via png, but not family
library(showtext)
dir(font_paths(), pattern = ".ttf")
font_add("comic", regular = "comic.ttf")
showtext_auto()
png("test.png", pointsize = 20)
par(family = "comic")
boxplot(alc ~ sex, data = cvd)
dev.off() 
showtext_auto(FALSE)

png("test.png", pointsize = 20)
showtext_begin()
par(family = "comic")
boxplot(alc ~ sex, data = cvd)
showtext_end()
dev.off() 



svg("test.svg", pointsize = 20)
par(family = "comic")
boxplot(alc ~ sex, data = cvd)
dev.off() 
showtext_auto(FALSE)



for (i in seq_along(devfun))
{
  devfun[[i]](paste("fig/bxplot_dev_modarg1", ext[i], sep="."), res=300, 
    width = 10, height = 10, units = "cm", )
  boxplot(alc ~ sex, data = cvd)
  dev.off()
}


## Vector formats: SVG, EPS, PDF
devfun_vec <- c(svg, pdf, postscript)
ext_vec    <- c("svg", "pdf", "ps")
for (i in seq_along(devfun_vec))
{
  devfun_vec[[i]](paste("fig/bxplot_dev_default", ext_vec[i], sep="."))
  boxplot(alc ~ sex, data = cvd)
  dev.off()
}

library(tibble)
tab <- tribble(
  ~Device, ~Extension, ~Type, ~"Use case", ~Comment, ~Link,
  "png", ".png", "bitmap", "Good default bitmap", "", "https://en.wikipedia.org/wiki/PNG_file_format",
  "jpeg", ".jpg, .jpeg", "bitmap", "Good default bitmap", "quality parameter", "https://en.wikipedia.org/wiki/JPEG_file_format",
  "tiff", ".tiff", "bitmap", "High-resolution bitmap", "large files", "https://en.wikipedia.org/wiki/TIFF",
  "bmp", ".bmp", "bitmap", "?", "Native windows/MS", "https://en.wikipedia.org/wiki/BMP_file_format",
  "svg", ".svg", "vector", "Goode default vector format for HTML", "", "https://en.wikipedia.org/wiki/SVG",
  "pdf", ".pdf", "vector", "Good default vector format for LaTeX, standalone documents", "", "https://en.wikipedia.org/wiki/PDF",
  "postscript", ".ps, .eps", "vector", "Older vector format for LaTeX", "", "https://en.wikipedia.org/wiki/PostScript"
)

#' Reasons to save to file:
#' 
#' * automate workflow (minimize manual steps, at least on the R side)
#' * replicability: related to previous point, but also make independet of 
#'   device size (Rstudio export copies graphic as seen in window)
#' * control proportions of plot better (for bitmaps, not so much for pdf)
#' * control resolution 
#' * control text / label size
#' * choose font via par() or similar    

#' This is an alternative to ggsave that works with all devices
#' Note: resizing works (see manhattan)
#' Note: pointsize does not seem to work on Unix - less surprising with dev.print,
#' which rescales to paper size (A4 by default here)
boxplot(alc ~ sex, data = cvd)
dev.print(png, filename = "Boxplot_printdev.png", width = 15, height = 15, 
          units = "cm", res = 300)
#' Does this work for ggplot2/grid? yes for ggplot2 (FIXME: test windows)
require(ggplot2)
ggplot(cvd, aes(x = cvd, y = alc, group = cvd)) + geom_boxplot()
dev.print(png, filename = "ggboxplot_printdev.png", width = 15, height = 15, 
          units = "cm", res = 300)
#' How does this work withr recordPlot or replayPlot? 


#' package R.devices: seems not that relevant these days?



#' Long plot
library(qqman)
manhattan(gwasResults)
dev.print(png, filename = "Manhattan_15x15.png", width = 15, height = 15, 
          units = "cm", res = 300)
dev.print(png, filename = "Manhattan_18x12.png", width = 18, height = 12, 
          units = "cm", res = 300)
dev.print(png, filename = "Manhattan_20x10.png", width = 20, height = 10, 
          units = "cm", res = 300)
dev.print(png, filename = "Manhattan_20x10_2.png", width = 20, height = 10, 
          units = "cm", res = 300, pointsize = 10)
dev.copy(png, filename = "Manhattan_25x10.png", width = 25, height = 10, 
          units = "cm", res = 300, pointsize = 10); dev.off()

png("Manhattan_25x10_2.png", width = 25, height = 10, units = "cm", res = 300, pointsize = 10)
manhattan(gwasResults)
dev.off()

#' Trimming: either par(mar=) etc. or...
library(magick)
mh <- image_read("Manhattan_25x10_2.png")
image_write(image_trim(mh), "Manhattan_25x10_2_trim.png")

#' Size of image and point size, line width.
png("Boxplot_5x5.png", width = 5, height = 5, units = "cm", res = 300)
boxplot(alc ~ sex, data = cvd)
dev.off()
png("Boxplot_10x10.png", width = 10, height = 10, units = "cm", res = 300)
boxplot(alc ~ sex, data = cvd)
dev.off()
png("Boxplot_20x20.png", width = 20, height = 20, units = "cm", res = 300)
boxplot(alc ~ sex, data = cvd)
dev.off()

#' How does this work for svg? Same thing!
svg("Boxplot_5x5.svg", width = 5, height = 5)
boxplot(alc ~ sex, data = cvd)
dev.off()
svg("Boxplot_10x10.svg", width = 10, height = 10)
boxplot(alc ~ sex, data = cvd)
dev.off()
svg("Boxplot_20x20.svg", width = 20, height = 20)
boxplot(alc ~ sex, data = cvd)
dev.off()

#' ragg devices: more posit 
#' https://cloud.r-project.org/web/packages/ragg/index.html
#' 

#' NB ggplot-scale does not affect the font, see 
#' https://www.tidyverse.org/blog/2020/08/taking-control-of-plot-scaling/
#' https://stackoverflow.com/questions/59218385/ggsave-scale-does-not-scale-text-size
#' 
#' NB, you can set the size in the plot, setting base_size in the theme;

library(ragg)
on_linux <- tolower(Sys.info()[['sysname']]) == 'linux'
fancy_font <- if (on_linux) 'URW Chancery L' else 'Papyrus'
agg_png("test_agg.png", pointsize = 20)
par(family = fancy_font)
boxplot(alc ~ sex, data = cvd)
dev.off() 
