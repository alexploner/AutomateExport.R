setwd("~/@OneDriveKI/DM_workshops/AutomateExportR/")
##setwd("~/../OneDrive - Karolinska Institutet/DM_workshops/AutomateExportR/")
cvd <- read.delim("CVD.txt", stringsAsFactors = TRUE)

#' Quick and powerful: gt + gtsummary
#' 
#' Pro: quick start with reasonable results; powerful if you invest time
#' Con: mostly Posit run; high dependency, unstable dev (Status: maturing etc.); ugly coding and interface
library(gtsummary)
tbl1 <- tbl_summary(cvd, by = "cvd", include = -ID)
tbl1
print(tbl1, print_engine = "kable")
gt::gtsave(as_gt(tbl1), "tab/gt_table1.docx")

lr <- glm(cvd ~ factor(alc3) + sex, data = cvd, family = binomial)
summary(lr)


#' Note style functions
tbl2 <- tbl_regression(lr, exponentiate = TRUE, label = list("factor(alc3)" ~ "Alcohol (3 level)"))
tbl2
print(tbl2, print_engine = "kable")

#' huxtable
#' 
#' About same number of dependencies as gt
#' One man show
#' Regression helper, descriptives? 
#' Powerful output options, if Office heavy
#' Is used as back-end from gt for some export formats (as_huxtable)
#' Mostly table formatting, assumes you already have a table, though it does 

#' offer some (ugly) regression tables directly

#' tinytable
#' 
#' NO dependencies
#' Simple interface, reasonable powerful
#' Only decoration
#' One person show, but fantastically simple UI; the opposite of gt, huxtable
#' general output

#' kableExtra
#' 
#' inspired by knotr::kable?
#' HTML and PDF as target output
#' Easy use fo styles
#' Reasonably sized command set, ncie enough stuff
#' decoration only

#' gtExtras


#' flextable
#' 
#' mostly decoration
#' some specials for building descriptive tables
#' some limits with grouping rows
#' freindly with data.table, with other ?
#' supports a handful of models (glm lm etc.) but not enough
#' output = word, pp, html, rtf, image, via save_as_*


#' arsenal
#' 
#' builds descriptive tables, among other things
#' much SAS inspired
#' implementation not exactly inspiring
#' Output = word, html, pdf vie write2* functions


#' table1
#' 
#' descriptives, formula interface, some syling
#' mostly HTML, some LaTeX
#' confuses content and format
#' allows for conversion to kable and flextable via t1kable and t1flex, where
#' the latter can be saved as Office format

#' tables
#' 
#' Duncan Murdoch
#' no dependencies
#' SAS inspired?
#' toTinytable!
#' weird formula notation, not very helpful vignette
#' Output: write as html or text via write*, bu can be converted to HTML, 
#' LaTeX, kable or tinytable, and therefore onwards!

psych::describe
psych::describeBy
Hmisc::describe

vtable: loads "datawizard", no

https://epirhandbook.com/new_pages/tables_descriptive.html


Work with prepared tables:
  
  
require(broom)
require(tinytable)
tidy(lr, conf.int = TRUE, exponentiate = TRUE) |> tt() -> jj
print(jj, output = "markdown")

require(poorman)
group_by(cvd, cvd) |> summarise(alc = mean(alc))
  

What works:
  table1 -> kable or flex via t1kable, t1flex

#' tinytable:
#' 
#' decoration only, super simple UI etc
#' Output: "latex", "markdown", "html", "typst", "dataframe" via print -> office? 


pander to Word / flextable?
  
or flextable as general intermediary?

see gtsummary::as_flex_table: gt does not support word (but does support rtf and html)

table1::t1flex 

# primary output from table1: html string, though content is preserved as string table
# table1 has as.data.frame
library(table1)
tab1 <- table1(~age+wt|treat, data = dat)
unclass(tab1)
tab1_df <- as.data.frame(tab1)
tab1_df
tinytable::tt(tab1_df)
## as utils for builign your own: stats.default + stats.apply.rounding
## use the render-argument to table1 to generate different summaries from stats.default
## for continuous, factor, missing values

## arsenal
## 
## data frame columns can have a label-attribute for display
## use summary to show
library(arsenal)
data(mockstudy)
tab1 <- tableby(arm ~ sex + age, data=mockstudy)
summary(tab1, text=TRUE)
## has as.data.frame, but does not resolve to actula table (long format)
as.data.frame(tab1)
## Formula notation with specials to define statistics, tests
## Complex list format internally
## Supports survival, date formats, though not necessarily as I would see them 
## (unclear delayerd entry, too)
## 
## has modelsum, but not what I would expect
## 
## write2html, write2pdf, write2word
## 
## some formatting tools, comparing to formatting options
## (weird naming convention)
